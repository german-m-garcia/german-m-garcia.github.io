import java.awt.geom.Point2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.StringTokenizer;
import java.util.Vector;

/*
 *  Copyright (C) 2010 Bonn University
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
/**
 * Reads and evaluates input result files of visual tracking systems. Evaluation
 * is done by computing the overlap of the rectangle around the object produced
 * by the tracking system with the corresponding ground truth rectangle.
 * 
 * For further information on BoBoT visit
 * http://www.iai.uni-bonn.de/~kleind/tracking/
 * 
 */
public class Evaluator {
    /** Holds a list of paths to the input result files. */
    private Vector<String> fileList;

    /**
     * Holds for every input result file the frame data along with some
     * additional information.
     */
    private Vector<FileData> fileData;

    /** The number of frames of the corresponding video. */
    private int numFrames;

    /** Vector of the coordinates of the ground truth rectangles. */
    private Vector<Point2D.Double> gtCoordinates;

    /** Vector of the dimensions of the ground truth rectangles. */
    private Vector<Dimension> gtDimensions;

    /** The name of the corresponding video. */
    private String vidName;

    /**
     * Constructs an Evaluator object with the given input arguments. The first
     * argument always has to be the path to the file containing the ground
     * truth data followed by arbitrarily many paths to input result files. The
     * latter ones can be abbreviated as follows:
     * 
     * path/file_name_basis\\n:m//.txt
     * 
     * This adds files path/file_name_basisn.txt through
     * path/file_name_basism.txt to the list of input result files. Of course, n
     * has to be less than m.
     * 
     * @param args
     *            Contains the path to the file holding the ground truth data
     *            followed by arbitrarily many paths to input result files.
     */
    public Evaluator(String[] args) {
        fileList = new Vector<String>(2);
        fileData = new Vector<FileData>(2);
        vidName = null;

        fillFileList(args);
    }

    /**
     * Fills the file list with the given input arguments.
     * 
     * @param args
     *            The redirected input arguments from the main method
     */
    private void fillFileList(String[] args) {
        fileList.add(args[0]);
        System.out.println("Added file " + args[0] + " to file list.");

        for (int i = 1; i < args.length; i++) {
            int beginIndex = args[i].lastIndexOf("\\");
            int endIndex = args[i].lastIndexOf("//");

            if (endIndex > beginIndex) {
                StringTokenizer tok = new StringTokenizer(args[i].substring(beginIndex + 1, endIndex), ":");
                int a = 0;
                int b = 0;
                if (tok.hasMoreTokens()) {
                    a = Integer.valueOf(tok.nextToken());
                } else {
                    System.out.println("Arguments for file specification missing.");
                    System.exit(1);
                }
                if (tok.hasMoreTokens()) {
                    b = Integer.valueOf(tok.nextToken());
                } else {
                    System.out.println("Second argument for file specification missing.");
                    System.exit(1);
                }

                if (a != 0 && b != 0 && a < b) {
                    for (int j = a; j <= b; j++) {
                        fileList.add(args[i].substring(0, beginIndex) + j + ".txt");
                        System.out.println("Added file " + args[i].substring(0, beginIndex) + j + ".txt to file list.");
                    }
                } else {
                    System.out.println("Wrong input: " + a + " > " + b);
                }
            } else {
                fileList.add(args[i]);
                System.out.println("Added file " + args[i] + " to file list.");
            }
        }
    }

    /**
     * Checks if all the given input result files really exist. If not, the path
     * of each missing file is printed to the console.
     * 
     * @return true if all files in the file list really exist, false otherwise
     */
    private boolean filesExist() {
        boolean result = true;

        for (int i = 0; i < fileList.size(); i++) {
            if (!new File(fileList.elementAt(i)).exists()) {
                System.out.println("Error: File " + fileList.elementAt(i) + " could not be found");
                result = false;
            }
        }
        return result;
    }

    /**
     * Reads all the files in the file list separately. For every file a
     * FileData object is generated that holds the file specific data.
     */
    private void readFiles() {
        System.out.println("Reading files.");
        try {
            BufferedReader foo = new BufferedReader(new FileReader(new File(fileList.elementAt(0))));
            int numLines = 0;
            String currentLine = null;
            while ((currentLine = foo.readLine()) != null) {
                numLines++;
                if (numLines == 1)
                    vidName = currentLine;
            }

            numFrames = numLines - 1;
            for (int i = 0; i < fileList.size(); i++) {
                FileData temp = new FileData(fileList.elementAt(i), numFrames, vidName);
                if (temp.readFile()) {
                    fileData.add(temp);
                    if (i == 0) {
                        gtCoordinates = temp.getCoordinates();
                        gtDimensions = temp.getDimensions();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("Number of read files: " + fileData.size());
    }

    /**
     * If all files exist they are read and evaluated. If one is missing the
     * process is aborted.
     * 
     * In the evaluation process for every frame the overlap of the rectangle
     * with the corresponding ground truth rectangle is computed. Afterwards the
     * results are printed to one single results file.
     */
    public void evaluate() {
        if (filesExist()) {
            System.out.println("Success: All given files exist!");
            readFiles();

            System.out.println("Files read. Starting evaluation...");
            Vector<Vector<Double>> fileResults = new Vector<Vector<Double>>(fileData.size());
            for (int i = 1; i < fileData.size(); i++) {
                fileResults.add(evaluateFile(i));
                System.out.println("File " + fileData.elementAt(i).getPath() + " evaluated.");
            }

            // compute per frame means and variances over all input files and
            // total mean and variance
            double[] means = new double[numFrames];
            double[] variances = new double[numFrames];
            double totMean = 0.0;
            double totVar = 0.0;
            for (int j = 0; j < numFrames; j++) {
                for (int i = 0; i < fileResults.size(); i++) {
                    double oldMean = means[j];
                    means[j] = oldMean + (fileResults.elementAt(i).elementAt(j) - oldMean) / (i + 1.0);

                    double oldVariance = variances[j];
                    variances[j] = (((double) i * oldVariance) / (i + 1.0)) + ((double) i * Math.pow(means[j] - oldMean, 2.0));
                }
                totMean += means[j];
                totVar += variances[j];
            }

            System.out.println("Files evaluated. Writing results...");
            try {
                File resultFile = new File("../results.txt");
                FileWriter fw = new FileWriter(resultFile);
                BufferedWriter bw = new BufferedWriter(fw);

                // 1st line: ground truth file
                bw.write("Ground truth file: " + vidName + "\n");

                // 2nd line: column headings
                bw.write("frame mean variance");
                for (int i = 1; i < fileList.size(); i++) {
                    bw.write(" " + fileList.elementAt(i).substring(fileList.elementAt(i).lastIndexOf("/")));
                }
                bw.write("\n");

                // 3rd line: overall means and variances and per file means
                bw.write("a " + formatNumber(totMean / numFrames) + " " + formatNumber(totVar / numFrames));
                double mean = 0.0;
                for (int i = 0; i < fileResults.size(); i++) {
                    mean = 0.0;
                    for (int j = 0; j < numFrames; j++) {
                        mean += fileResults.elementAt(i).elementAt(j);
                    }
                    mean /= numFrames;
                    bw.write(" " + formatNumber(mean));
                }
                bw.write("\n");

                // 4th to nth line: per frame results
                for (int i = 0; i < numFrames; i++) {
                    bw.write(i + " " + formatNumber(means[i]) + " " + formatNumber(variances[i]));
                    for (int j = 0; j < fileResults.size(); j++) {
                        bw.write(" " + formatNumber(fileResults.elementAt(j).elementAt(i)));
                    }
                    bw.write("\n");
                }
                bw.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

            System.out.println("Results written. Closing programm.");
        }
    }

    /**
     * Formats a double into a string of fixed length.
     * 
     * @param num
     *            The number to be formatted
     * @return The resulting string
     */
    private String formatNumber(double num) {
        return String.format("%.10f", num);
    }

    /**
     * Evaluates the input result file with the given index. For every frame the
     * proportion of the overlap of a frame rectangle with the corresponding
     * ground truth rectangle is computed and stored in a vector.
     * 
     * @param index
     *            The index of the file in the file list that is to be evaluated
     * 
     * @return A Vector of Double that contains for each frame the proportion of
     *         overlap of the frame rectangle with the corresponding gound truth
     *         rectanlge
     */
    private Vector<Double> evaluateFile(int index) {
        Vector<Point2D.Double> fileCoordinates = fileData.elementAt(index).getCoordinates();
        Vector<Dimension> fileDimensions = fileData.elementAt(index).getDimensions();
        Vector<Double> result = new Vector<Double>(numFrames);

        for (int i = 0; i < numFrames; i++) {
            double minX = Math.min(gtCoordinates.elementAt(i).x, fileCoordinates.elementAt(i).x);
            double maxX = Math.max(gtCoordinates.elementAt(i).x, fileCoordinates.elementAt(i).x);
            double minY = Math.min(gtCoordinates.elementAt(i).y, fileCoordinates.elementAt(i).y);
            double maxY = Math.max(gtCoordinates.elementAt(i).y, fileCoordinates.elementAt(i).y);

            // Two paraxial rectangles intersect, iff the width of their
            // bounding box is smaller than the combined widths of the two
            // rectangles AND the height of the bounding box is smaller than the
            // combined heights of the two rectangles
            if (maxX - minX < gtDimensions.elementAt(i).getWidth() + fileDimensions.elementAt(i).getWidth()
                    && maxY - minY < gtDimensions.elementAt(i).getHeight() + fileDimensions.elementAt(i).getHeight()
                    && !(gtDimensions.elementAt(i).getWidth() == 0 && gtDimensions.elementAt(i).getHeight() == 0)
                    && !(fileDimensions.elementAt(i).getWidth() == 0 && fileDimensions.elementAt(i).getHeight() == 0)) {
                double upperX = maxX;
                double upperY = maxY;
                double lowerX = Math.min(gtCoordinates.elementAt(i).x + gtDimensions.elementAt(i).getWidth(), fileCoordinates
                        .elementAt(i).x
                        + fileDimensions.elementAt(i).getWidth());
                double lowerY = Math.min(gtCoordinates.elementAt(i).y + gtDimensions.elementAt(i).getHeight(), fileCoordinates
                        .elementAt(i).y
                        + fileDimensions.elementAt(i).getHeight());

                double areaOverlap = Math.abs(upperX - lowerX) * Math.abs(upperY - lowerY);
                double areaGT = gtDimensions.elementAt(i).getWidth() * gtDimensions.elementAt(i).getHeight();
                double areaFile = fileDimensions.elementAt(i).getWidth() * fileDimensions.elementAt(i).getHeight();
                double proportionOverlap = areaOverlap / (areaGT + areaFile - areaOverlap);

                result.add(i, proportionOverlap);
            } else {
                result.add(i, 0.0);
            }
        }

        return result;
    }

    /**
     * The main method, where an Evaluator object is created and the process of
     * evaluation is started.
     * 
     * @param args
     *            First argument is the path to the ground truth file, followed
     *            by arbitrarily many paths to input result files
     */
    public static void main(String[] args) {
        if (args.length >= 2) {
            Evaluator eval = new Evaluator(args);
            eval.evaluate();
        } else {
            System.out.println("Usage: java Evaluator path_to_ground_truth.txt list_of_paths_to_result_files.txt");
        }
    }
}
