import java.awt.geom.Point2D;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.StringTokenizer;
import java.util.Vector;

/*
 *  Copyright (C) 2010 Bonn University
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
/**
 * Holds the rectangle data along with some other information for one single
 * input result file.
 * 
 * For further information on BoBoT visit
 * http://www.iai.uni-bonn.de/~kleind/tracking/
 */
public class FileData {
    /** Vector of coordinates for all rectangles in the input result file */
    private Vector<Point2D.Double> coordinates;

    /** Vector of dimensions for all rectangles in the input result file */
    private Vector<Dimension> dimensions;

    /** The name of the corresponding video file */
    String vidName;

    /** The number of frames of the video */
    int numFrames;

    /** The path to the input result file */
    String path;

    /**
     * Constructs a FileData object that holds the rectangle data along with
     * some other information for one single input file.
     * 
     * @param path
     *            The path to the input result file
     * @param numFrames
     *            The number of frames of the video
     * @param vidName
     *            The name of the corresponding video file
     */
    public FileData(String path, int numFrames, String vidName) {
        coordinates = new Vector<Point2D.Double>(numFrames);
        dimensions = new Vector<Dimension>(numFrames);
        for (int i = 0; i < numFrames; i++) {
            coordinates.add(new Point2D.Double(0.0, 0.0));
            dimensions.add(new Dimension(0, 0));
        }

        this.path = path;
        this.vidName = vidName;
        this.numFrames = numFrames;
    }

    /**
     * Returns the path of the input result file.
     * 
     * @return The path of the input result file
     */
    public String getPath() {
        return path;
    }

    /**
     * Returns the coordinates of all rectangles in the input result file.
     * 
     * @return The coordinates of all rectangles in the input result file
     */
    public Vector<Point2D.Double> getCoordinates() {
        return coordinates;
    }

    /**
     * Returns the dimensions of all rectangles in the input result file.
     * 
     * @return The dimensions of all rectangles in the input result file
     */
    public Vector<Dimension> getDimensions() {
        return dimensions;
    }

    /**
     * Reads the input result file. 
     */
    public boolean readFile() {
        try {
            File tempFile = new File(path);
            FileReader tempFR = new FileReader(tempFile);
            BufferedReader tempBR = new BufferedReader(tempFR);
            String currentLine = null;
            int lineNumber = 0;
            while ((currentLine = tempBR.readLine()) != null) {
                lineNumber++;
                if (lineNumber == 1 && !currentLine.equals(vidName)) {
                    System.err.println("File " + path + " does not capture the correct video file, ground truth says " + vidName);
                } else if (lineNumber > 1) {
                    if (!parseLine(currentLine)) {
                        System.out.println("Error in file " + path + " in line " + lineNumber + " --> Skipping file");
                        return false;
                    }
                }
            }
            System.out.println("Read file " + path);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Parses one line of the input result file.
     * 
     * @param line
     *            The line to be parsed
     */
    private boolean parseLine(String line) {
        StringTokenizer tok = new StringTokenizer(line, " \t");
        int index = 0;
        double a = 0;
        double b = 0;
        double c = 0;
        double d = 0;
        double numValues = 0;

        if (tok.hasMoreTokens()) {
            index = Integer.valueOf(tok.nextToken());
            numValues++;
        }
        if (tok.hasMoreTokens()) {
            a = Double.valueOf(tok.nextToken());
            numValues++;
        }
        if (tok.hasMoreTokens()) {
            b = Double.valueOf(tok.nextToken());
            numValues++;
        }
        if (tok.hasMoreTokens()) {
            c = Double.valueOf(tok.nextToken());
            numValues++;
        }
        if (tok.hasMoreTokens()) {
            d = Double.valueOf(tok.nextToken());
            numValues++;
        }

        if (numValues == 5 && !tok.hasMoreTokens() && index >= 0 && index < numFrames) {
            coordinates.add(index, new Point2D.Double(a, b));
            dimensions.add(index, new Dimension(c, d));
            return true;
        } else {
            return false;
        }
    }
}
